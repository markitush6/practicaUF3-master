package com.company;

import models.Hospital;
import models.Paciente;
import models.Persona;
import models.Sanitario;
import utilitats.Utilities;

import java.util.ArrayList;

public class Main {
    final static String MENUPACIENTE = "Elije un opcion: " +
            "\n\t1.Pedir cita " +
            "\n\t2.Vacuna Covid" +
            "\n\t3.Test Covid" +
            "\n\t4.Salir";

    final static String MENUSANITARIO = "Elige una de las opciones :" +
            "\t\n1.Crear nueva persona" +
            "\t\n2.Eliminar datos de la persona" +
            "\t\n3.Modificar datos de la persona" +
            "\t\n4.Vacunar" +
            "\t\n5.Hacer operacion" +
            "\t\n6.Consultas" +
            "\t\n7.Test Covid" +
            "\t\n8.Salir";

    public static void main(String[] args) {
        int opcio;

        ArrayList<Persona> persones = Hospital.initPersonas();

        System.out.println("\tBienvinid@ al programa!");

        Hospital hospital = new Hospital(Utilities.llegirFrase("Escribe el nombre del hospital :"),
                Utilities.llegirFrase("Escribe la direccion del hospital :"),
                Utilities.llegirBoolean("El hospital es privado? (si/no)"));
        System.out.println(hospital);

        Persona persona = elegirPersona(persones);

        if (persona instanceof Paciente) {
            opcio = Utilities.llegirInt(MENUPACIENTE, 1, 4);
            menuPaciente(opcio, persones, persona);
        } else if (persona instanceof Sanitario) {
            opcio = Utilities.llegirInt(MENUSANITARIO, 1, 8);
            menuSanitario(opcio, persones, persona);
        }

    }

    public static void menuPaciente(int opcio, ArrayList<Persona> persones, Persona persona) {
        do {
            switch (opcio) {
                case 1:
                    persona.pedirCita();
                    break;
                case 2:
                    persona.vacuna();
                    break;
                case 3:
                    persona.testCovid();
                    break;
                case 4:
                    //seleccionarPersona();
                    //odificarPersona();
                    break;
                case 5:
                    //citaPrevia();
                    break;
                case 6:
                    //vacunar();
                    break;
                case 7:
                    //testCovid();
                    break;
                case 8:
                    System.out.println("Adeuuu.....");
                    break;
                default:
                    System.out.println("Eror");
                    break;

            }
        } while (opcio != 8);
    }
    public static void menuSanitario(int opcio, ArrayList<Persona> persones, Persona persona) {
        do {
                switch (opcio) {
                    case 1:
                        Hospital.crearPersona(persones);
                        System.out.println(persones);
                        break;
                    case 2:
                        Hospital.eliminarPersona(persones);
                        break;
                    case 3:
                        Hospital.modificarPersona(persones);
                        break;
                    case 4:
                        persona.vacunar();
                        break;
                    case 5:
                        persona.hacerOperacion();
                        break;;
                    case 6:
                        persona.revisarPaciente();
                        break;
                    case 7:
                        persona.consulta();
                        break;

                }
            } while (opcio != 8);
    }

    private static Persona elegirPersona( ArrayList<Persona> persona) {
        Persona persones = null;
        int indexPersona;

        Hospital.imprimirPersonas(persona);
        String registroPersona = Utilities.llegirFrase("Estas registrado?");

        if (registroPersona.equalsIgnoreCase("si")) {
            indexPersona = Utilities.llegirInt("Elige la persona :", 0, persona.size() - 1);
            persones = persona.get(indexPersona);
        } else if (registroPersona.equalsIgnoreCase("no")) {
            persones = Hospital.crearPersona(persona);
        }
        System.out.println(persones);
        return persones;
    }
}

package interfaces;

public interface AccionPaciente {
    void pedirCita();
    void vacunaCovid();
    void testCovid();
}

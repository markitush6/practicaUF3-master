package interfaces;

public interface AccionSanitario {
    void vacunar();
    void hacerOperacion();
    void revisarPaciente();
    void testCovid();
}

package models;

import interfaces.AccionSanitario;
import utilitats.Utilities;

import java.time.LocalDate;

public class Doctor extends Sanitario implements AccionSanitario {
    private boolean esJefe;
    private float salario;


    public Doctor(String DNI, String nombre, String apellido1, String apellido2, LocalDate fechaNacimiento, String grado, String especialidad, int anosExperiencia, boolean esJefe, float salario) {
        super(DNI, nombre, apellido1, apellido2, fechaNacimiento, grado, especialidad, anosExperiencia);
        this.esJefe = esJefe;
        this.salario = salario;
    }


    @Override
    public void vacunar() {
        System.out.println("Yo no vacunó");
    }

    @Override
    public void hacerOperacion() {
        System.out.println(this.nombre +"está haciendo una operación!");
    }

    @Override
    public void revisarPaciente() {
        System.out.println(this.nombre +"está revisando un paciente!");
    }

    @Override
    public void testCovid() {
    boolean estat = Utilities.llegirBoolean("Has dado positivo");
    if (estat == true){
        System.out.println("Confinado 7 dias, mucha agua i paracetamol cada 8 horas ");
    } else{
        System.out.println("Eres negativo, deja el cuento ves a trabajar.");
    }
    }
}

package models;

import interfaces.AccionSanitario;

import java.time.LocalDate;

public class Pasante extends Sanitario implements AccionSanitario {
    private String nombreUni;
    private char nivel;

    public Pasante(String DNI, String nombre, String apellido1, String apellido2, LocalDate fechaNacimiento, String grado, String especialidad, int anosExperiencia, String nombreUni, char nivel) {
        super(DNI, nombre, apellido1, apellido2, fechaNacimiento, grado, especialidad, anosExperiencia);
        this.nombreUni = nombreUni;
        this.nivel = nivel;
    }

    @Override
    public String toString() {
        return "Pasante{" +
                "nombreUni='" + nombreUni + '\'' +
                ", nivel=" + nivel +
                ", nombre='" + nombre + '\'' +
                ", apellido1='" + apellido1 + '\'' +
                ", apellido2='" + apellido2 + '\'' +
                '}';
    }

    @Override
    public void vacunar() {
    
    }

    @Override
    public void hacerOperacion() {

    }

    @Override
    public void revisarPaciente() {

    }
    

    @Override
    public void testCovid() {

    }
}

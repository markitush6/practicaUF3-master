package models;

import interfaces.AccionSanitario;

import java.time.LocalDate;

public class Sanitario extends Persona{
    private String grado;
    private String especialidad;
    private int anosExperiencia;

    public Sanitario(String DNI, String nombre, String apellido1, String apellido2, LocalDate fechaNacimiento, String grado, String especialidad, int anosExperiencia) {
        super(DNI, nombre, apellido1, apellido2, fechaNacimiento);
        this.grado = grado;
        this.especialidad = especialidad;
        this.anosExperiencia = anosExperiencia;
    }

    @Override
    public String toString() {
        return "Sanitario{" +
                "nombre='" + nombre + '\'' +
                ", apellido1='" + apellido1 + '\'' +
                ", apellido2='" + apellido2 + '\'' +
                ", grado='" + grado + '\'' +
                ", especialidad='" + especialidad + '\'' +
                ", anosExperiencia=" + anosExperiencia +
                '}';
    }
}
